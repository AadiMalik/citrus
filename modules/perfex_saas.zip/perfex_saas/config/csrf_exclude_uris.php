<?php

defined('BASEPATH') or exit('No direct script access allowed');
if (!defined('PERFEX_SAAS_ROUTE_NAME')) return [];

return [
    PERFEX_SAAS_ROUTE_NAME . '/api\/.+',
];