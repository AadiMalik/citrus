<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<?php $CI = &get_instance(); ?>

<!-- load registration form widget -->
<?php require_once('register.php'); ?>

<!-- load onboarding tour guide widget -->
<?php require_once('onboarding.php'); ?>