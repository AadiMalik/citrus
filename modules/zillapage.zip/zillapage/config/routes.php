<?php

defined('BASEPATH') or exit('No direct script access allowed');

$route['zillapage/formsubmission'] = 'publishlandingpage/formsubmission';
$route['zillapage/getpagejson'] = 'publishlandingpage/getpagejson';
$route['zillapage/getblockscss'] = 'publishlandingpage/getblockscss';
