<?php

defined('BASEPATH') or exit('No direct script access allowed');

$route['publish/(:any)'] = 'zillapage/publishlandingpage/index/$1';
$route['publish/thankyou/(:any)'] = 'zillapage/publishlandingpage/thankyou/$1';