$(function(){
    "use strict"; // Start of use strict
    initDataTable('.table-blocks', window.location.href, [5], [5]);
});
