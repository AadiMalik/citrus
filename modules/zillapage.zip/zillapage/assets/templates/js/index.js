$(function(){
	"use strict"; // Start of use strict
    initDataTable('.table-templates', window.location.href, [4], [4]);
});