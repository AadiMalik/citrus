$(function(){
	"use strict"; // Start of use strict
	initDataTable('.table-landingpages', window.location.href, undefined, [1,3], undefined, [2,'desc']);
});