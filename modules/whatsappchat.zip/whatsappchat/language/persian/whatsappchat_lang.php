<?php
#  Version 1.0
$lang['whatsappchat'] = 'WhatsApp Chat';

