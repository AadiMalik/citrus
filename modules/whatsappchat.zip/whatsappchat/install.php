<?php

defined('BASEPATH') or exit('No direct script access allowed');

add_option('whatsappchat', 'enable');
add_option('whatsappchat_admin_area', '');
add_option('whatsappchat_clients_area', '');
add_option('whatsappchat_clients_and_admin_area', '');