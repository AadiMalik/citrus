<?php defined('BASEPATH') or exit('No direct script access allowed');

// Remove options
delete_option('page_builder_options');